package com.example.ejercicio_cuadrados;

public class ActividadPrincipal {
}
